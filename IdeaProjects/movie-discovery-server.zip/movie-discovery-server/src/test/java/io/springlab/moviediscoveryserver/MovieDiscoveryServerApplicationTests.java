package io.springlab.moviediscoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
