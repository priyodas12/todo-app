package io.springlab.moviediscoveryserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieDiscoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieDiscoveryServerApplication.class, args);
	}

}
