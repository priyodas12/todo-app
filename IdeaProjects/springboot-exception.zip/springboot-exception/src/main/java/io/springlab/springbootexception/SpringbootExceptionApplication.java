package io.springlab.springbootexception;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootExceptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootExceptionApplication.class, args);
	}

}
