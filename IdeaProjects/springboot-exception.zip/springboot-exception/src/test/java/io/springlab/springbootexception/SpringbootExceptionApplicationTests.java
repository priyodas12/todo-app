package io.springlab.springbootexception;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootExceptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
